package com.alex.bacterium;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class BacteriumMod implements ModInitializer {
    public static final String MOD_ID = "bacterium";
    private static final int CONNECTED_BATCH = 2048;
    private static final int RADIUS_BATCH = 4096;
    private static final int YELLOW_RADIUS = 50;

    public static BacteriumBlock GREEN_BACTERIUM;
    public static BacteriumBlock RED_BACTERIUM;
    public static BacteriumBlock YELLOW_BACTERIUM;
    public static BacteriumBlock BLUE_BACTERIUM;

    private static final Map<UUID, WorldTasks> TASKS = new HashMap<>();

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        GREEN_BACTERIUM = register("green_bacterium", BacteriumBlock.Mode.GREEN);
        RED_BACTERIUM = register("red_bacterium", BacteriumBlock.Mode.RED);
        YELLOW_BACTERIUM = register("yellow_bacterium", BacteriumBlock.Mode.YELLOW);
        BLUE_BACTERIUM = register("blue_bacterium", BacteriumBlock.Mode.BLUE);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(GREEN_BACTERIUM);
            entries.add(RED_BACTERIUM);
            entries.add(YELLOW_BACTERIUM);
            entries.add(BLUE_BACTERIUM);
        });

        ServerTickEvents.END_WORLD_TICK.register(BacteriumMod::tickWorld);
    }

    private static BacteriumBlock register(String name, BacteriumBlock.Mode mode) {
        Identifier identifier = id(name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, identifier);
        BacteriumBlock block = new BacteriumBlock(
                mode,
                AbstractBlock.Settings.copy(Blocks.SLIME_BLOCK)
                        .strength(0.6f)
                        .ticksRandomly()
                        .registryKey(blockKey)
        );
        Registry.register(Registries.BLOCK, identifier, block);

        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, identifier);
        Registry.register(
                Registries.ITEM,
                identifier,
                new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey())
        );
        return block;
    }

    static void tryActivate(ServerWorld world, BlockPos origin, BacteriumBlock.Mode mode) {
        WorldTasks worldTasks = TASKS.computeIfAbsent(world.getRegistryKey().getValue().hashCode() == 0
                ? UUID.nameUUIDFromBytes(world.getRegistryKey().getValue().toString().getBytes())
                : UUID.nameUUIDFromBytes(world.getRegistryKey().getValue().toString().getBytes()), ignored -> new WorldTasks());

        long key = origin.asLong();
        if (!worldTasks.activeOrigins.add(key)) {
            return;
        }

        if (mode == BacteriumBlock.Mode.YELLOW) {
            worldTasks.radiusTasks.add(new RadiusTask(origin.toImmutable()));
            return;
        }

        BlockPos below = origin.down();
        BlockState target = world.getBlockState(below);
        if (target.isAir() || isBacterium(target)) {
            worldTasks.activeOrigins.remove(key);
            return;
        }

        BlockState replacement;
        if (mode == BacteriumBlock.Mode.GREEN) {
            replacement = world.getBlockState(origin.up());
            if (replacement.isAir() || isBacterium(replacement)) {
                worldTasks.activeOrigins.remove(key);
                return;
            }
        } else if (mode == BacteriumBlock.Mode.RED) {
            replacement = Blocks.AIR.getDefaultState();
        } else {
            replacement = Blocks.OAK_LEAVES.getDefaultState().with(Properties.WATERLOGGED, true);
        }

        worldTasks.connectedTasks.add(new ConnectedTask(origin.toImmutable(), target, replacement));
    }

    private static void tickWorld(ServerWorld world) {
        UUID id = UUID.nameUUIDFromBytes(world.getRegistryKey().getValue().toString().getBytes());
        WorldTasks tasks = TASKS.get(id);
        if (tasks == null) {
            return;
        }

        Iterator<ConnectedTask> connected = tasks.connectedTasks.iterator();
        while (connected.hasNext()) {
            ConnectedTask task = connected.next();
            if (task.tick(world)) {
                tasks.activeOrigins.remove(task.origin.asLong());
                connected.remove();
            }
        }

        Iterator<RadiusTask> radius = tasks.radiusTasks.iterator();
        while (radius.hasNext()) {
            RadiusTask task = radius.next();
            if (task.tick(world)) {
                tasks.activeOrigins.remove(task.origin.asLong());
                radius.remove();
            }
        }

        if (tasks.connectedTasks.isEmpty() && tasks.radiusTasks.isEmpty()) {
            TASKS.remove(id);
        }
    }

    private static boolean isBacterium(BlockState state) {
        Block b = state.getBlock();
        return b == GREEN_BACTERIUM || b == RED_BACTERIUM || b == YELLOW_BACTERIUM || b == BLUE_BACTERIUM;
    }

    private static final class WorldTasks {
        private final Set<Long> activeOrigins = new HashSet<>();
        private final java.util.List<ConnectedTask> connectedTasks = new java.util.ArrayList<>();
        private final java.util.List<RadiusTask> radiusTasks = new java.util.ArrayList<>();
    }

    private static final class ConnectedTask {
        private final BlockPos origin;
        private final BlockState target;
        private final BlockState replacement;
        private final Deque<BlockPos> queue = new ArrayDeque<>();
        private final Set<Long> visited = new HashSet<>();

        private ConnectedTask(BlockPos origin, BlockState target, BlockState replacement) {
            this.origin = origin;
            this.target = target;
            this.replacement = replacement;
            queue.add(origin.down());
        }

        private boolean tick(ServerWorld world) {
            int processed = 0;
            while (processed < CONNECTED_BATCH && !queue.isEmpty()) {
                BlockPos pos = queue.removeFirst();
                long packed = pos.asLong();
                if (!visited.add(packed)) {
                    continue;
                }

                if (pos.getY() >= origin.getY()) {
                    continue;
                }

                BlockState current = world.getBlockState(pos);
                if (!current.equals(target)) {
                    continue;
                }

                world.setBlockState(pos, replacement, Block.NOTIFY_ALL);
                processed++;

                queue.add(pos.down());
                queue.add(pos.north());
                queue.add(pos.south());
                queue.add(pos.west());
                queue.add(pos.east());

                BlockPos up = pos.up();
                if (up.getY() < origin.getY()) {
                    queue.add(up);
                }
            }
            return queue.isEmpty();
        }
    }

    private static final class RadiusTask {
        private final BlockPos origin;
        private int dx = -YELLOW_RADIUS;
        private int dy = -YELLOW_RADIUS;
        private int dz = -YELLOW_RADIUS;

        private RadiusTask(BlockPos origin) {
            this.origin = origin;
        }

        private boolean tick(ServerWorld world) {
            int processed = 0;
            int r2 = YELLOW_RADIUS * YELLOW_RADIUS;

            while (processed < RADIUS_BATCH && dx <= YELLOW_RADIUS) {
                if (dx * dx + dy * dy + dz * dz <= r2) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    BlockState current = world.getBlockState(pos);
                    if (!current.isAir() && !isBacterium(current)) {
                        BlockState replacement = netherify(current);
                        if (!replacement.equals(current)) {
                            world.setBlockState(pos, replacement, Block.NOTIFY_ALL);
                        }
                    }
                    processed++;
                }

                dz++;
                if (dz > YELLOW_RADIUS) {
                    dz = -YELLOW_RADIUS;
                    dy++;
                    if (dy > YELLOW_RADIUS) {
                        dy = -YELLOW_RADIUS;
                        dx++;
                    }
                }
            }
            return dx > YELLOW_RADIUS;
        }
    }

    private static BlockState netherify(BlockState state) {
        Block block = state.getBlock();

        if (block == Blocks.WATER) return Blocks.LAVA.getDefaultState();
        if (block == Blocks.GRASS_BLOCK || block == Blocks.PODZOL || block == Blocks.MYCELIUM || block == Blocks.MOSS_BLOCK)
            return Blocks.CRIMSON_NYLIUM.getDefaultState();
        if (block == Blocks.DIRT || block == Blocks.COARSE_DIRT || block == Blocks.ROOTED_DIRT || block == Blocks.MUD || block == Blocks.CLAY)
            return Blocks.SOUL_SOIL.getDefaultState();
        if (block == Blocks.SAND || block == Blocks.RED_SAND || block == Blocks.GRAVEL)
            return Blocks.SOUL_SAND.getDefaultState();

        if (state.isIn(BlockTags.LOGS)) return Blocks.CRIMSON_STEM.getDefaultState();
        if (state.isIn(BlockTags.LEAVES)) return Blocks.NETHER_WART_BLOCK.getDefaultState();
        if (state.isIn(BlockTags.PLANKS)) return Blocks.CRIMSON_PLANKS.getDefaultState();

        if (block == Blocks.STONE_BRICKS || block == Blocks.CRACKED_STONE_BRICKS || block == Blocks.MOSSY_STONE_BRICKS
                || block == Blocks.CHISELED_STONE_BRICKS || block == Blocks.BRICKS)
            return Blocks.NETHER_BRICKS.getDefaultState();

        if (block == Blocks.COBBLESTONE || block == Blocks.MOSSY_COBBLESTONE)
            return Blocks.BLACKSTONE.getDefaultState();
        if (block == Blocks.DEEPSLATE || block == Blocks.COBBLED_DEEPSLATE)
            return Blocks.BASALT.getDefaultState();
        if (block == Blocks.ICE || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE || block == Blocks.SNOW_BLOCK)
            return Blocks.MAGMA_BLOCK.getDefaultState();

        if (state.isIn(BlockTags.FLOWERS) || block == Blocks.GRASS || block == Blocks.FERN || block == Blocks.DEAD_BUSH)
            return Blocks.CRIMSON_ROOTS.getDefaultState();

        return Blocks.NETHERRACK.getDefaultState();
    }
}

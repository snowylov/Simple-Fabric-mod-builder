package com.alex.bacterium;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public final class BacteriumBlock extends Block {
    public enum Mode { GREEN, RED, YELLOW, BLUE }

    private final Mode mode;

    public BacteriumBlock(Mode mode, Settings settings) {
        super(settings);
        this.mode = mode;
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return null;
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (world instanceof ServerWorld serverWorld) {
            BacteriumMod.tryActivate(serverWorld, pos, mode);
        }
    }

    @Override
    protected void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        BacteriumMod.tryActivate(world, pos, mode);
    }
}
